<?php

/**
 * %PLUGIN_HEADER%
 */

class Bug_Monitor_Loader {

	public static function load(){            
		$plugins = get_option('active_plugins');
		$plugin_file = '%PLUGIN_DIR%main.php';
		if (in_array('%PLUGIN_BASENAME%', (array)$plugins) && file_exists($plugin_file)){
			include_once $plugin_file;
		}
	}
}
Bug_Monitor_Loader::load();
?>
