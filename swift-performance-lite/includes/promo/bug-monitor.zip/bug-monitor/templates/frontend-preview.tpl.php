<div class="bm-preview-element-missing bm-preview-message bm-hidden">
      <div class="bm-preview-element-missing-head">
            <img src="<?php echo BUG_MONITOR_PLUGIN_URL?>/images/logo.png">
      </div>
      <p>
            <strong><?php esc_html_e('The problematic element is not present in this live preview.', 'bug-monitor')?></strong><br><br>
            <?php esc_html_e('The user may have been logged in, or the element might have a different class or ID and cannot be identified. It is not ideal, but it sometimes happens. If the issue occurs again, BugMonitor probably be able to capture a video or screenshot so you can identify it.', 'bug-monitor')?><br><br>
            <a href="#" class="bm-close-this"><?php esc_html_e('OK', 'bug-monitor')?></a>
      </p>
</div>

<div class="bm-preview-not-in-viewport bm-preview-message bm-hidden">
      <div class="bm-preview-element-missing-head">
            <img src="<?php echo BUG_MONITOR_PLUGIN_URL?>/images/logo.png">
      </div>
      <p>
            <strong><?php esc_html_e('The problematic element is not in the viewport.', 'bug-monitor')?></strong><br><br>
            <?php esc_html_e('The element is probably shown only upon user interaction (e.g., an exit popup or an off-canvas menu).', 'bug-monitor')?><br><br>
            <a href="#" class="bm-close-this"><?php esc_html_e('OK', 'bug-monitor')?></a>
      </p>
</div>