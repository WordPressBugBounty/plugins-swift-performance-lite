<?php echo Bug_Monitor_Dashboard::get_description($data);?>
<?php if (!empty($data['details']['issue']) && $data['details']['issue'] == 'missing'):?>
      <?php esc_html_e('Probably, the title is generated dynamically, but proper logic has not been set.', 'bug-monitor');?><br><br>
      <?php echo sprintf(esc_html__('It is recommended to use a %sSEO plugin%s to add missing titles and to fix an incorrect ones.', 'bug-monitor'), '<a href="https://wordpress.org/plugins/search/seo/" target="_blank">', '</a>');?>
<?php endif;