<?php
$type = Bug_Monitor_Helper::get_file_type($data['details']['url']);
echo sprintf(esc_html__('There is %s %s file (%s%s%s) on the page which couldn\'t be loaded due a HTTP error.', 'bug-monitor'), Bug_Monitor_Helper::choose_article($type), $type, '<a href="' . esc_url($data['details']['url']) . '" target="_blank">', esc_url($data['details']['url']), '</a>');

?>