<?php echo Bug_Monitor_Dashboard::get_description($data);?>
<br><br>
<?php esc_html_e('If the font size is too small, reading on small screens can be challenging. Google recommends using a font size of 16px or larger, which may seem a bit strict. However, you should use at least 12px.');?><br><br>
<?php if (!empty($data['preview_link'])):?>
<a href="<?php echo esc_attr($data['preview_link']);?>" target="_blank" class="bm-btn-large">
      <img src="<?php echo BUG_MONITOR_PLUGIN_URL;?>/images/icons/link-preview.svg">
      <?php esc_html_e('Live Preview', 'bug-monitor');?>
</a>
<br><br>
<?php endif;?>
<?php echo sprintf(esc_html__('The following text is hard to read because it is too small: %s%s%s'), '<br><span class="bm-highlight">', $data['details']['text'], '</span>');?>
