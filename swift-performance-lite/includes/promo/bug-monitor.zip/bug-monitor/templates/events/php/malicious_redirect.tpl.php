<?php echo sprintf(__('A suspicious redirect has been detected. The site has been redirected to a third party URL: %s', 'bug-monitor'), '<strong>' . $data['details']['redirect_to'] . '</strong>');?><br><br>
<h2><?php esc_html_e('Cookies:', 'bug-monitor');?></h2>
<ul>
<?php foreach ($data['details']['cookies'] as $key => $value):?>
      <li><strong><?php echo $key;?>:</strong> <?php echo $value;?></li>
<?php endforeach;?>
</ul>
<h2><?php esc_html_e('Headers:', 'bug-monitor');?></h2>
<ul>
<?php foreach ($data['details']['headers'] as $key => $value):?>
      <li><strong><?php echo $key;?>:</strong> <?php echo $value;?></li>
<?php endforeach;?>
</ul>