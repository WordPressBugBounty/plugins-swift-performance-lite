<?php echo sprintf(__('A PHP error was caused by %s %s', 'bug-monitor'), Bug_Monitor_Helper::choose_article($data['details']['component']), $data['details']['component']);?><br><br>
<?php echo sprintf(esc_html__('File: %s%s%s', 'bug-monitor'), '<strong>', $data['details']['file'], '</strong>');?>
<?php if (!empty($data['details']['line'])):?>
      <?php echo sprintf(esc_html__('(line: %s)', 'bug-monitor'), $data['details']['line']);?>
<?php endif;?>
<br>
<pre class="bm-php-error-wrapper"><?php echo esc_html($data['details']['message']);?></pre>
