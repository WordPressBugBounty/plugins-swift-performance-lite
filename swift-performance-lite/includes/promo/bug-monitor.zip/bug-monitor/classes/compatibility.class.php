<?php

class Bug_Monitor_Compatibility {

      public static function init(){
            add_filter('bug_monitor/disable_frontend', array(__CLASS__, 'disable_frontend'));
      }

      public static function disable_frontend(){
            if (isset($_GET['fl_builder'])){
                  return true;
            }
            if (isset($_GET['breakdance']) || isset($_GET['breakdance_iframe'])){
                  return true;
            }
            if (isset($_GET['bricks']) && $_GET['bricks'] == 'run'){
                  return true;
            }
            if (isset($_GET['is-editor-iframe']) || (isset($_GET['action']) && $_GET['action'] == 'in-front-editor')){
                  return true;
            }
            if (isset($_GET['et_fb'])){
                  return true;
            }
            if (isset($_GET['elementor-preview'])){
                  return true;
            }
            if (isset($_GET['ct_builder'])){
                  return true;
            }
      }

}